<?php
    define('MODULE_PAYMENT_UNITPAY_TEXT_TITLE', 'Unitpay');
    define('MODULE_PAYMENT_UNITPAY_TEXT_DESCRIPTION', 'Unitpay.ru');
    define('MODULE_PAYMENT_UNITPAY_PUBLIC_KEY_TITLE', 'PUBLIC KEY');
    define('MODULE_PAYMENT_UNITPAY_SECRET_KEY_TITLE', 'SECRET KEY');
    define('MODULE_PAYMENT_UNITPAY_SORT_ORDER_TITLE', 'Sort order');
    define('MODULE_PAYMENT_UNITPAY_ORDER_PAY_STATUS_TITLE', 'Select the order status that will be assigned after the payment through this module');
    define('MODULE_PAYMENT_UNITPAY_ORDER_ERROR_STATUS_TITLE', 'Select the order status that will be assigned after the error payment through this module');
    define('MODULE_PAYMENT_UNITPAY_CALLBACK_TITLE', 'URL request handler for dashboard Unitpay.ru');

